
<script type="text/javascript" src="jquery.min.js"></script>

<script src="gooeymenu.js">
 

</script>

<link rel="stylesheet" type="text/css" href="styles.css" />

<ul id="gooeymenu1" class="gelbuttonmenu">
<li><a href="home.php">Home</a></li>
<li><a href="show_inquiry.php">Show_inquiry</a></li>
<li><a href="show_user.php">Show User </a></li>
<li><a href="show_feedback.php">Show Feedback</a></li>
<li><a href="show_order.php">Show Order</a></li>
<li><a href="prod.php">Product Mgmt.</a></li>
<li><a href="a_transfer.php">Transfer Mgmt. </a></li>
<li><a href="show_city_mgnt.php">City Mgmt</a></li>
<li><a href="show_godown.php">Godown</a></li>
<li><a href="show_news.php">Show_News</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>

<script>
gooeymenu.setup({id:'gooeymenu1', selectitem:1})
</script>


