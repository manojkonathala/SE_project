                   <ul>
						<li><a href="index.php" class="active">Home</a></li>
						<li><a href="activities.php">Activities</a></li>
						<li><a href="order.php">Order</a></li>
						<li><a href="register.php">Registration</a></li>
						<li><a href="inquiry.php">Inquiry</a></li>
						<li><a href="feedback.php">Feedback</a></li>
						<li><a href="myprofile.php">Myprofile</a></li>
						<li><a href="contact.php">Contact</a></li>
					    <li><a href="login.php">Login</a></li>
                        <li><a href="Logout.php">Logout</a></li>
						
					</ul>